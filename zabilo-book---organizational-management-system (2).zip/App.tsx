
import React, { useState, useEffect, createContext, useContext } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Profile } from './types';
import { INITIAL_PROFILES } from './mockData';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Requests from './pages/Requests';
import UsersAdmin from './pages/Admin/Users';
import DepartmentsAdmin from './pages/Admin/Departments';
import SettingsAdmin from './pages/Admin/Settings';
import Layout from './components/Layout';

interface AuthContextType {
  user: Profile | null;
  login: (username: string, pass: string) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
};

const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<Profile | null>(() => {
    const saved = localStorage.getItem('zabilo_user');
    return saved ? JSON.parse(saved) : null;
  });

  useEffect(() => {
    if (!localStorage.getItem('zabilo_users')) {
      localStorage.setItem('zabilo_users', JSON.stringify(INITIAL_PROFILES));
    }
  }, []);

  const login = async (username: string, pass: string): Promise<boolean> => {
    const savedUsersStr = localStorage.getItem('zabilo_users');
    const usersList: Profile[] = savedUsersStr ? JSON.parse(savedUsersStr) : INITIAL_PROFILES;
    
    const found = usersList.find(p => 
      p.username.toLowerCase() === username.toLowerCase() && 
      p.password_hash === pass
    );
    
    if (found) {
      const { password_hash, ...publicProfile } = found;
      setUser(publicProfile as Profile);
      localStorage.setItem('zabilo_user', JSON.stringify(publicProfile));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('zabilo_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

const ProtectedRoute: React.FC<{ children: React.ReactNode; adminOnly?: boolean }> = ({ children, adminOnly }) => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (adminOnly && user.role !== 'admin') return <Navigate to="/dashboard" replace />;
  return <Layout>{children}</Layout>;
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <HashRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/requests" element={<ProtectedRoute><Requests /></ProtectedRoute>} />
          <Route path="/admin/users" element={<ProtectedRoute adminOnly><UsersAdmin /></ProtectedRoute>} />
          <Route path="/admin/departments" element={<ProtectedRoute adminOnly><DepartmentsAdmin /></ProtectedRoute>} />
          <Route path="/admin/settings" element={<ProtectedRoute adminOnly><SettingsAdmin /></ProtectedRoute>} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </HashRouter>
    </AuthProvider>
  );
};

export default App;
