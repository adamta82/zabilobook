
import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../App';
import { 
  LayoutDashboard, 
  Send, 
  Users, 
  Building2, 
  LogOut, 
  Menu, 
  Bell,
  Settings
} from 'lucide-react';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const navItems = [
    { name: 'הלוח הארגוני', path: '/dashboard', icon: LayoutDashboard },
    { name: 'ניהול בקשות', path: '/requests', icon: Send },
  ];

  const adminItems = [
    { name: 'ניהול עובדים', path: '/admin/users', icon: Users },
    { name: 'ניהול מחלקות', path: '/admin/departments', icon: Building2 },
    { name: 'הגדרות וובהוק', path: '/admin/settings', icon: Settings },
  ];

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const renderNavLink = (item: any) => {
    const isActive = location.pathname === item.path;
    return (
      <Link
        key={item.path}
        to={item.path}
        onClick={() => setIsSidebarOpen(false)}
        className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 group ${
          isActive 
            ? 'bg-primary-50 text-primary shadow-sm ring-1 ring-primary-200/50' 
            : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
        }`}
      >
        <item.icon size={18} className={`${isActive ? 'text-primary' : 'text-slate-400 group-hover:text-slate-600'}`} />
        <span className="font-semibold text-sm">{item.name}</span>
      </Link>
    );
  };

  return (
    <div className="flex min-h-screen bg-white text-slate-900" dir="rtl">
      {/* Mobile Overlay */}
      {isSidebarOpen && (
        <div className="fixed inset-0 bg-slate-900/10 z-40 md:hidden backdrop-blur-[1px]" onClick={() => setIsSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 right-0 z-50 w-64 bg-slate-50 border-l border-slate-200 transition-transform duration-300 md:translate-x-0 md:static md:block
        ${isSidebarOpen ? 'translate-x-0' : 'translate-x-full'}
      `}>
        <div className="h-full flex flex-col px-4 py-8">
          <div className="mb-10 px-2 flex flex-col items-center">
            <div className="flex items-center gap-3">
              <div className="bg-primary w-9 h-9 rounded-lg text-white shadow-xl flex items-center justify-center font-black text-xl">Z</div>
              <span className="text-xl font-black text-slate-900 tracking-tight">Zabilo Book</span>
            </div>
          </div>

          <nav className="flex-1 space-y-1">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 px-2">תפריט ראשי</div>
            {navItems.map(renderNavLink)}

            {user?.role === 'admin' && (
              <div className="mt-10">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 px-2">ניהול אדמין</div>
                {adminItems.map(renderNavLink)}
              </div>
            )}
          </nav>

          <div className="mt-auto pt-4 border-t border-slate-200">
            <div className="flex items-center gap-3 px-2 mb-6">
              <div className="w-9 h-9 rounded-full bg-primary-100 flex items-center justify-center text-primary font-bold text-xs border border-primary-200 shadow-sm">
                {user?.full_name?.charAt(0)}
              </div>
              <div className="flex-1 overflow-hidden">
                <p className="text-sm font-bold text-slate-900 truncate">{user?.full_name}</p>
                <p className="text-[10px] text-slate-500 truncate font-medium">{user?.role === 'admin' ? 'אדמין' : 'עובד'}</p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-3 w-full px-3 py-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all font-semibold text-sm"
            >
              <LogOut size={18} />
              <span>התנתקות</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="h-14 bg-white/80 backdrop-blur-md border-b border-slate-100 flex items-center justify-between px-8 sticky top-0 z-30">
          <button className="md:hidden p-2 text-slate-600 hover:bg-slate-50 rounded-lg" onClick={() => setIsSidebarOpen(true)}>
            <Menu size={20} />
          </button>
          <div className="flex-1" />
          <div className="flex items-center gap-5">
            <button className="text-slate-400 hover:text-slate-600 transition-colors relative">
              <Bell size={20} />
              <span className="absolute top-0 left-0 w-2 h-2 bg-primary rounded-full border-2 border-white"></span>
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 lg:p-12 bg-white selection:bg-primary-100">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
