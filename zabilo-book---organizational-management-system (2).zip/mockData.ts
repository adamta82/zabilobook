
import { Profile, Department, Category, Article, Announcement, FAQ } from './types';

export const INITIAL_DEPARTMENTS: Department[] = [
  { id: '1', name: 'פיתוח' },
  { id: '2', name: 'משאבי אנוש' },
  { id: '3', name: 'שיווק' },
  { id: '4', name: 'מכירות' },
];

export const INITIAL_PROFILES: Profile[] = [
  {
    id: 'admin-id',
    username: 'admin',
    full_name: 'מנהל מערכת',
    email: 'admin@zabilo.com',
    phone: '050-0000000',
    department_id: '2',
    approver_id: null,
    calendar_emails: ['hr@zabilo.com', 'management@zabilo.com'],
    role: 'admin',
    password_hash: 'admin123'
  },
  {
    id: 'user-id',
    username: 'user1',
    full_name: 'ישראל ישראלי',
    email: 'israel@zabilo.com',
    phone: '054-1234567',
    department_id: '1',
    approver_id: 'admin-id',
    calendar_emails: ['admin@zabilo.com'],
    role: 'employee',
    password_hash: 'user123'
  }
];

export const INITIAL_CATEGORIES: Category[] = [
  { id: '1', name: 'נהלי עבודה' },
  { id: '2', name: 'מדריכים טכניים' },
  { id: '3', name: 'הטבות ורווחה' },
];

// Initial mock data for the Knowledge Center
export const INITIAL_ARTICLES: Article[] = [
  {
    id: '1',
    title: 'מדריך עבודה מרחוק',
    summary: 'כל הכלים והנהלים לעבודה אפקטיבית מהבית.',
    content: 'בעולם המודרני, עבודה מרחוק היא חלק בלתי נפרד מהתרבות הארגונית. ב-Zabilo אנו מעודדים גמישות תוך שמירה על רמת ביצועים גבוהה.',
    category_id: '1',
    view_count: 150,
    published_at: '2024-11-01'
  },
  {
    id: '2',
    title: 'הגדרת VPN במחשב חברה',
    summary: 'צעד אחר צעד לחיבור מאובטח לרשת הארגונית מהבית.',
    content: 'כדי להבטיח את אבטחת המידע שלנו, יש להשתמש בחיבור VPN בכל פעם שעובדים מרחוק. המדריך הבא מפרט את שלבי ההגדרה.',
    category_id: '2',
    view_count: 85,
    published_at: '2024-11-05'
  }
];

export const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: '1',
    title: 'מסיבת חנוכה במשרד!',
    content: 'חברים יקרים, מוזמנים להדלקת נרות חגיגית, סופגניות ופינוקים ביום ראשון הקרוב ב-16:00 במטבח המרכזי.',
    author_name: 'רווחה',
    is_pinned: true,
    created_at: '2024-12-01'
  },
  {
    id: '2',
    title: 'עדכון מערכת הגשת בקשות',
    content: 'המערכת שודרגה לגרסה 2.5. ניתן כעת להוסיף רשימת פריטים לבקשות ציוד ומצרכים.',
    author_name: 'IT',
    is_pinned: false,
    created_at: '2024-11-28'
  }
];

export const INITIAL_FAQS: FAQ[] = [
  {
    id: '1',
    question: 'איך אני מדווח שעות עבודה מהבית?',
    answer: 'דיווח השעות מתבצע דרך ממשק הבקשות במערכת Zabilo Book. יש להזין את פירוט המשימות ושעות העבודה עבור כל בקשת WFH.'
  },
  {
    id: '2',
    question: 'מה המדיניות לגבי חופשות ארוכות?',
    answer: 'עבור חופשה העולה על 4 ימי עבודה, יש להגיש בקשה לפחות חודש מראש ולקבל אישור מהמנהל הישיר ומהנהלת החברה.'
  }
];
