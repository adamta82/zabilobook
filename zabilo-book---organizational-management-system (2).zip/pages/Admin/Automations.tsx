
import React, { useState, useEffect } from 'react';
import { 
  Zap, 
  Trash2, 
  X, 
  Activity, 
  Link as LinkIcon, 
  Settings, 
  ArrowDown, 
  Code, 
  Filter, 
  Send,
  PlusCircle,
  Info,
  Clock,
  Save,
  Mail,
  Globe,
  Layout
} from 'lucide-react';
import { Automation, AutomationTrigger, RequestType, AutomationHeader, AutomationActionType } from '../../types';

const AutomationsAdmin: React.FC = () => {
  const [automations, setAutomations] = useState<Automation[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [trigger, setTrigger] = useState<AutomationTrigger>('request_created');
  const [filterType, setFilterType] = useState<RequestType | 'all'>('all');
  const [actionType, setActionType] = useState<AutomationActionType>('webhook');
  
  // Webhook State
  const [url, setUrl] = useState('');
  const [method, setMethod] = useState<'POST' | 'GET' | 'PUT' | 'DELETE'>('POST');
  const [headers, setHeaders] = useState<AutomationHeader[]>([{ key: 'Content-Type', value: 'application/json' }]);
  
  // Email State
  const [emailSubject, setEmailSubject] = useState('בקשה חדשה ממתינה לאישורך: {{request_type}} - {{user_name}}');
  
  const defaultWebhookPayload = `{
  "request": {
    "id": "{{request_id}}",
    "type": "{{request_type}}",
    "status": "{{status}}",
    "reason": "{{reason}}"
  },
  "employee": {
    "name": "{{user_name}}",
    "email": "{{user_email}}",
    "approver_email": "{{approver_email}}",
    "calendar_emails": "{{calendar_emails}}",
    "phone": "{{user_phone}}",
    "dept": "{{user_department}}"
  }
}`;

  const defaultEmailBody = `שלום {{user_approver}},

הוגשה בקשה חדשה מסוג {{request_type}} על ידי העובד {{user_name}} (מחלקה: {{user_department}}).

פרטי הבקשה:
סיבה: {{reason}}
תאריכים: {{start_date}} עד {{end_date}}
נוצר ב: {{created_at}}

לו"ז משימות מפורט:
{{tasks_table}}

פרטי קשר של העובד:
טלפון: {{user_phone}}
אימייל: {{user_email}}

לצפייה בבקשה וביצוע אישור/דחייה במערכת, לחץ על הקישור הבא:
{{system_link}}

בברכה,
מערכת Zabilo Book`;

  const [payload, setPayload] = useState(defaultWebhookPayload);

  useEffect(() => {
    const saved = localStorage.getItem('zabilo_automations');
    if (saved) {
      setAutomations(JSON.parse(saved));
    }
  }, []);

  const saveAutomationsToStore = (updated: Automation[]) => {
    setAutomations(updated);
    localStorage.setItem('zabilo_automations', JSON.stringify(updated));
  };

  const handleToggle = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = automations.map(a => a.id === id ? { ...a, is_active: !a.is_active } : a);
    saveAutomationsToStore(updated);
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('האם אתה בטוח שברצונך למחוק אוטומציה זו?')) {
      const updated = automations.filter(a => a.id !== id);
      saveAutomationsToStore(updated);
    }
  };

  const handleEdit = (auto: Automation) => {
    setEditingId(auto.id);
    setName(auto.name);
    setTrigger(auto.trigger_type);
    setFilterType(auto.filter_request_type);
    setActionType(auto.action_type || 'webhook');
    setUrl(auto.webhook_url || '');
    setMethod(auto.method || 'POST');
    setHeaders(auto.headers || [{ key: 'Content-Type', value: 'application/json' }]);
    setEmailSubject(auto.email_subject || '');
    setPayload(auto.payload_template);
    setIsModalOpen(true);
  };

  const handleAddHeader = () => setHeaders([...headers, { key: '', value: '' }]);
  const removeHeader = (idx: number) => setHeaders(headers.filter((_, i) => i !== idx));
  const updateHeader = (idx: number, field: 'key' | 'value', val: string) => {
    setHeaders(headers.map((h, i) => i === idx ? { ...h, [field]: val } : h));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    
    const automationData: Automation = {
      id: editingId || Math.random().toString(36).substr(2, 9),
      name,
      trigger_type: trigger,
      filter_request_type: filterType,
      action_type: actionType,
      webhook_url: actionType === 'webhook' ? url : undefined,
      method: actionType === 'webhook' ? method : undefined,
      headers: actionType === 'webhook' ? headers.filter(h => h.key.trim() !== '') : undefined,
      email_subject: actionType === 'email' ? emailSubject : undefined,
      payload_template: payload,
      is_active: editingId ? (automations.find(a => a.id === editingId)?.is_active ?? true) : true,
      created_at: editingId ? (automations.find(a => a.id === editingId)?.created_at ?? new Date().toISOString()) : new Date().toISOString(),
      last_run: editingId ? automations.find(a => a.id === editingId)?.last_run : undefined
    };

    let newAutomations;
    if (editingId) {
      newAutomations = automations.map(a => a.id === editingId ? automationData : a);
    } else {
      newAutomations = [automationData, ...automations];
    }

    saveAutomationsToStore(newAutomations);
    setIsModalOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setEditingId(null);
    setName('');
    setTrigger('request_created');
    setFilterType('all');
    setActionType('webhook');
    setUrl('');
    setMethod('POST');
    setHeaders([{ key: 'Content-Type', value: 'application/json' }]);
    setEmailSubject('בקשה חדשה ממתינה לאישורך: {{request_type}} - {{user_name}}');
    setPayload(defaultWebhookPayload);
  };

  const copyVariable = (v: string) => {
    navigator.clipboard.writeText(`{{${v}}}`);
  };

  const variables = [
    { key: 'request_type', label: 'סוג' },
    { key: 'user_name', label: 'שם עובד' },
    { key: 'user_email', label: 'מייל עובד' },
    { key: 'approver_email', label: 'מייל מאשר' },
    { key: 'calendar_emails', label: 'רשימת מיילים קלנדר' },
    { key: 'user_phone', label: 'טלפון עובד' },
    { key: 'user_department', label: 'מחלקה' },
    { key: 'user_approver', label: 'שם מאשר' },
    { key: 'reason', label: 'סיבה' },
    { key: 'tasks_table', label: 'טבלת לו"ז' },
    { key: 'system_link', label: 'קישור' }
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-10 animate-in fade-in duration-700 pb-20">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight">אוטומציות ותהליכים</h1>
          <p className="text-slate-500 font-medium mt-2">הגדרת חוקים עסקיים, שליחת מיילים וחיבור למערכות חיצוניות.</p>
        </div>
        <button 
          onClick={() => { resetForm(); setIsModalOpen(true); }}
          className="bg-primary text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-2 hover:bg-primary-600 transition-all shadow-xl shadow-primary-200/50 hover:-translate-y-1"
        >
          <PlusCircle size={22} />
          צור אוטומציה חדשה
        </button>
      </div>

      <div className="space-y-4">
        <h2 className="text-lg font-black text-slate-800 flex items-center gap-2 px-2">
          <Settings size={20} className="text-primary" />
          ניהול תהליכי עבודה קיימים
        </h2>
        
        {automations.map(auto => (
          <div 
            key={auto.id} 
            onClick={() => handleEdit(auto)}
            className={`bg-white border-2 rounded-[32px] p-6 transition-all hover:border-primary-200 cursor-pointer group relative ${!auto.is_active ? 'border-slate-100 opacity-60' : 'border-slate-50 shadow-sm'}`}
          >
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="flex items-center gap-5">
                <div className={`p-4 rounded-2xl ${auto.is_active ? 'bg-primary-50 text-primary' : 'bg-slate-100 text-slate-400'}`}>
                  {auto.action_type === 'email' ? <Mail size={24} /> : <Zap size={24} />}
                </div>
                <div>
                  <h3 className="font-black text-lg text-slate-900">{auto.name}</h3>
                  <div className="flex flex-wrap items-center gap-4 mt-1">
                    <span className="text-xs text-slate-400 font-bold flex items-center gap-1">
                      <Clock size={12} />
                      {auto.last_run ? `ריצה אחרונה: ${new Date(auto.last_run).toLocaleTimeString('he-IL')}` : 'טרם הופעל'}
                    </span>
                    <span className={`text-xs font-black uppercase tracking-tighter flex items-center gap-1 ${auto.action_type === 'email' ? 'text-amber-600' : 'text-primary-500'}`}>
                      {auto.action_type === 'email' ? <Mail size={12} /> : <Globe size={12} />}
                      {auto.action_type === 'email' ? 'אימייל למנהל' : `${auto.method} Webhook`}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button 
                  onClick={(e) => handleToggle(auto.id, e)}
                  className={`px-4 py-2 rounded-xl font-bold text-sm transition-all border ${auto.is_active ? 'bg-emerald-50 text-emerald-700 border-emerald-100 hover:bg-emerald-100' : 'bg-slate-100 text-slate-500 border-slate-200'}`}
                >
                  {auto.is_active ? 'פעיל' : 'כבוי'}
                </button>
                <div className="w-px h-8 bg-slate-100 mx-2"></div>
                <button onClick={(e) => handleDelete(auto.id, e)} className="p-3 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all">
                  <Trash2 size={20} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-4xl rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 border border-slate-100">
            <div className="px-10 py-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
                  <Layout className="text-primary" />
                  {editingId ? 'עריכת תהליך' : 'בונה תהליכים (Workflow)'}
                </h3>
                <p className="text-slate-400 font-medium text-sm mt-1">השתמש במשתנים כדי להזריק את כל פרטי העובד והבקשה.</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-3 hover:bg-slate-200/50 rounded-full text-slate-400 transition-colors">
                <X size={28} />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-10 space-y-10 max-h-[75vh] overflow-y-auto custom-scrollbar">
              <div className="space-y-6">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center font-black text-xs">1</div>
                  <h4 className="font-black text-slate-800 text-lg uppercase tracking-tight">הגדרת אירוע וסינון</h4>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-50/50 p-8 rounded-3xl border border-slate-100">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-500 uppercase px-1">שם האוטומציה</label>
                    <input type="text" required value={name} onChange={(e) => setName(e.target.value)} className="w-full px-5 py-3.5 bg-white border border-slate-200 rounded-2xl outline-none font-bold" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-500 uppercase px-1">מתי להפעיל?</label>
                    <select value={trigger} onChange={(e) => setTrigger(e.target.value as any)} className="w-full px-5 py-3.5 bg-white border border-slate-200 rounded-2xl outline-none font-bold">
                      <option value="request_created">בקשה חדשה נוצרה</option>
                      <option value="request_approved">בקשה אושרה</option>
                      <option value="request_rejected">בקשה נדחתה</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-500 uppercase px-1">סינון סוג בקשה</label>
                    <select value={filterType} onChange={(e) => setFilterType(e.target.value as any)} className="w-full px-5 py-3.5 bg-white border border-slate-200 rounded-2xl outline-none font-bold">
                      <option value="all">הכל</option>
                      <option value="WFH">עבודה מהבית</option>
                      <option value="Vacation">חופשה</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="flex justify-center py-2"><ArrowDown className="text-slate-200" size={32} /></div>

              <div className="space-y-6">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-500 text-white flex items-center justify-center font-black text-xs">2</div>
                  <h4 className="font-black text-slate-800 text-lg uppercase tracking-tight">בחירת סוג פעולה</h4>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <button 
                    type="button" 
                    onClick={() => { setActionType('webhook'); setPayload(defaultWebhookPayload); }}
                    className={`p-6 rounded-3xl border-2 flex items-center gap-4 transition-all ${actionType === 'webhook' ? 'border-primary bg-primary-50 text-primary ring-4 ring-primary-100' : 'border-slate-100 bg-white text-slate-400'}`}
                  >
                    <Globe size={24} />
                    <div className="text-right">
                      <p className="font-black text-sm">Webhook חיצוני</p>
                    </div>
                  </button>
                  <button 
                    type="button" 
                    onClick={() => { setActionType('email'); setPayload(defaultEmailBody); }}
                    className={`p-6 rounded-3xl border-2 flex items-center gap-4 transition-all ${actionType === 'email' ? 'border-amber-500 bg-amber-50 text-amber-700 ring-4 ring-amber-100' : 'border-slate-100 bg-white text-slate-400'}`}
                  >
                    <Mail size={24} />
                    <div className="text-right">
                      <p className="font-black text-sm">התראת אימייל למאשר</p>
                    </div>
                  </button>
                </div>

                <div className={`p-8 rounded-3xl border space-y-8 ${actionType === 'email' ? 'bg-amber-50/20 border-amber-100' : 'bg-primary-50/10 border-primary-100'}`}>
                  {actionType === 'webhook' ? (
                    <div className="grid grid-cols-4 gap-4">
                      <select value={method} onChange={(e) => setMethod(e.target.value as any)} className="px-4 py-3 bg-white border border-slate-200 rounded-xl font-bold">
                        <option value="POST">POST</option>
                        <option value="GET">GET</option>
                      </select>
                      <input type="url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="URL..." className="col-span-3 px-4 py-3 bg-white border border-slate-200 rounded-xl font-bold outline-none" />
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <label className="text-xs font-black text-amber-700 uppercase px-1">נושא האימייל</label>
                      <input type="text" value={emailSubject} onChange={(e) => setEmailSubject(e.target.value)} className="w-full px-5 py-3.5 bg-white border border-amber-100 rounded-xl outline-none font-bold text-amber-900" />
                    </div>
                  )}

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-black text-slate-500 uppercase px-1 flex items-center gap-2">
                        <Code size={14} />
                        תבנית תוכן (הזרקת שדות עובד ובקשה)
                      </label>
                      <div className="flex flex-wrap gap-1 justify-end max-w-md">
                        {variables.map(v => (
                          <button key={v.key} type="button" onClick={() => copyVariable(v.key)} title={`העתק {{${v.key}}}`} className="text-[9px] font-bold bg-white text-slate-500 px-2 py-1 rounded border border-slate-200 hover:bg-slate-50">
                            {v.label}
                          </button>
                        ))}
                      </div>
                    </div>
                    <textarea 
                      value={payload} onChange={(e) => setPayload(e.target.value)}
                      className="w-full h-64 p-6 bg-slate-900 text-emerald-400 font-mono text-xs rounded-2xl border-none focus:ring-4 focus:ring-primary-500/20 leading-relaxed custom-scrollbar"
                      dir={actionType === 'webhook' ? 'ltr' : 'rtl'}
                    />
                  </div>
                </div>
              </div>

              <div className="pt-10 flex gap-6">
                <button type="submit" className="flex-[2] bg-primary text-white font-black py-5 rounded-3xl hover:bg-primary-600 shadow-2xl shadow-primary-200 transition-all flex items-center justify-center gap-3">
                  <Save size={22} />
                  שמור אוטומציה
                </button>
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 bg-slate-100 text-slate-500 font-bold py-5 rounded-3xl hover:bg-slate-200 transition-all">ביטול</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AutomationsAdmin;
