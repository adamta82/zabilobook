
import React, { useState } from 'react';
import { BookOpen, Bell, HelpCircle, Plus, Search, Edit2, Trash2 } from 'lucide-react';
import { INITIAL_ARTICLES, INITIAL_ANNOUNCEMENTS, INITIAL_FAQS } from '../../mockData';

const ContentAdmin: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'articles' | 'announcements' | 'faq'>('articles');

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">ניהול תוכן</h1>
          <p className="text-slate-500">עריכת מאמרים, הודעות ושאלות נפוצות.</p>
        </div>
        <div className="flex gap-2 bg-white p-1.5 border border-slate-200 rounded-2xl shadow-sm">
          <button
            onClick={() => setActiveTab('articles')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'articles' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <BookOpen size={18} />
            מאמרים
          </button>
          <button
            onClick={() => setActiveTab('announcements')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'announcements' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <Bell size={18} />
            עדכונים
          </button>
          <button
            onClick={() => setActiveTab('faq')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'faq' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <HelpCircle size={18} />
            FAQ
          </button>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div className="relative max-w-sm w-full">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="חפש בתוכן..."
              className="w-full pr-10 pl-4 py-2 bg-slate-50 border border-slate-100 rounded-xl outline-none text-sm"
            />
          </div>
          <button className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-slate-800 transition-all">
            <Plus size={18} />
            {activeTab === 'articles' ? 'מאמר חדש' : activeTab === 'announcements' ? 'עדכון חדש' : 'שאלה חדשה'}
          </button>
        </div>

        <div className="divide-y divide-slate-100">
          {activeTab === 'articles' && INITIAL_ARTICLES.map(item => (
            <div key={item.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
              <div>
                <h3 className="font-bold text-slate-900">{item.title}</h3>
                <p className="text-xs text-slate-400 mt-1">נצפה {item.view_count} פעמים • פורסם ב-{new Date(item.published_at).toLocaleDateString('he-IL')}</p>
              </div>
              <div className="flex gap-2">
                <button className="p-2 text-slate-400 hover:text-blue-600 rounded-lg"><Edit2 size={18} /></button>
                <button className="p-2 text-slate-400 hover:text-rose-600 rounded-lg"><Trash2 size={18} /></button>
              </div>
            </div>
          ))}
          {activeTab === 'announcements' && INITIAL_ANNOUNCEMENTS.map(item => (
            <div key={item.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
              <div>
                <h3 className="font-bold text-slate-900">{item.title}</h3>
                <p className="text-xs text-slate-400 mt-1">מאת: {item.author_name} • {new Date(item.created_at).toLocaleDateString('he-IL')}</p>
              </div>
              <div className="flex gap-2">
                <button className="p-2 text-slate-400 hover:text-blue-600 rounded-lg"><Edit2 size={18} /></button>
                <button className="p-2 text-slate-400 hover:text-rose-600 rounded-lg"><Trash2 size={18} /></button>
              </div>
            </div>
          ))}
          {activeTab === 'faq' && INITIAL_FAQS.map(item => (
            <div key={item.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
              <div>
                <h3 className="font-bold text-slate-900">{item.question}</h3>
                <p className="text-xs text-slate-400 mt-1 line-clamp-1">{item.answer}</p>
              </div>
              <div className="flex gap-2">
                <button className="p-2 text-slate-400 hover:text-blue-600 rounded-lg"><Edit2 size={18} /></button>
                <button className="p-2 text-slate-400 hover:text-rose-600 rounded-lg"><Trash2 size={18} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ContentAdmin;
