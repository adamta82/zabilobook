
import React, { useState } from 'react';
import { INITIAL_DEPARTMENTS } from '../../mockData';
import { Department } from '../../types';
import { Building2, Plus, Edit2, Trash2, X } from 'lucide-react';

const DepartmentsAdmin: React.FC = () => {
  const [departments, setDepartments] = useState<Department[]>(INITIAL_DEPARTMENTS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const newDept = { id: Math.random().toString(), name };
    setDepartments([...departments, newDept]);
    setIsModalOpen(false);
    setName('');
  };

  const removeDept = (id: string) => {
    setDepartments(departments.filter(d => d.id !== id));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">ניהול מחלקות</h1>
          <p className="text-slate-500">הגדרת מבנה ארגוני ושיוך עובדים.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
        >
          <Plus size={20} />
          מחלקה חדשה
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {departments.map(dept => (
          <div key={dept.id} className="bg-white border border-slate-200 p-6 rounded-2xl flex items-center justify-between hover:shadow-md transition-all group">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl group-hover:scale-110 transition-transform">
                <Building2 size={24} />
              </div>
              <span className="font-bold text-lg text-slate-800">{dept.name}</span>
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 text-slate-400 hover:text-blue-600 rounded-lg hover:bg-slate-50"><Edit2 size={18} /></button>
              <button onClick={() => removeDept(dept.id)} className="p-2 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-50"><Trash2 size={18} /></button>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl animate-in zoom-in-95">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-xl font-bold">הוספת מחלקה</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-full">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleAdd} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-sm font-bold text-slate-500">שם המחלקה</label>
                <input 
                  type="text" 
                  required 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500/20" 
                  placeholder="למשל: תפעול"
                />
              </div>
              <div className="pt-4">
                <button type="submit" className="w-full bg-emerald-600 text-white font-bold py-2.5 rounded-xl shadow-lg shadow-emerald-100">צור מחלקה</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default DepartmentsAdmin;
