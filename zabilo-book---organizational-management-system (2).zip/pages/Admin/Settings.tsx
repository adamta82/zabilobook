
import React, { useState, useEffect } from 'react';
import { Webhook, Save, CheckCircle, AlertCircle, RefreshCcw } from 'lucide-react';
import { AppSettings } from '../../types';

const SettingsAdmin: React.FC = () => {
  const [webhookUrl, setWebhookUrl] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');

  useEffect(() => {
    const saved = localStorage.getItem('zabilo_settings');
    if (saved) {
      const settings: AppSettings = JSON.parse(saved);
      setWebhookUrl(settings.webhook_url || '');
    }
  }, []);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setStatus('idle');

    setTimeout(() => {
      const settings: AppSettings = { webhook_url: webhookUrl };
      localStorage.setItem('zabilo_settings', JSON.stringify(settings));
      setIsSaving(false);
      setStatus('success');
      setTimeout(() => setStatus('idle'), 3000);
    }, 800);
  };

  const testWebhook = async () => {
    if (!webhookUrl) return;
    setIsSaving(true);
    try {
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          event: "test_connection", 
          timestamp: new Date().toISOString(),
          message: "בדיקת חיבור וובהוק ממערכת Zabilo Book"
        })
      });
      if (response.ok) alert('חיבור הצלח! הוובהוק הופעל בהצלחה.');
      else alert('הוובהוק הופעל אך החזיר שגיאה: ' + response.status);
    } catch (e) {
      alert('שגיאה בחיבור לוובהוק: ' + (e as Error).message);
    }
    setIsSaving(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10 animate-in fade-in duration-700">
      <div>
        <h1 className="text-4xl font-black text-slate-900 tracking-tight">הגדרות מערכת</h1>
        <p className="text-slate-500 font-medium mt-2">הגדרת חיבורים חיצוניים ודיווחים אוטומטיים.</p>
      </div>

      <div className="bg-white border border-slate-200 rounded-[40px] overflow-hidden shadow-xl shadow-slate-100">
        <div className="p-10 border-b border-slate-100 bg-slate-50/30">
          <div className="flex items-center gap-4">
            <div className="bg-primary-100 p-4 rounded-2xl text-primary">
              <Webhook size={32} />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900">חיבור Webhook גלובלי</h2>
              <p className="text-slate-400 font-medium text-sm mt-1">כל פעולה במערכת (בקשה חדשה, אישור, דחייה) תישלח לכתובת זו ב-JSON.</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSave} className="p-10 space-y-8">
          <div className="space-y-3">
            <label className="text-xs font-black text-slate-500 uppercase tracking-widest mr-1">כתובת Webhook (URL)</label>
            <input 
              type="url" 
              required 
              value={webhookUrl}
              onChange={(e) => setWebhookUrl(e.target.value)}
              className="w-full h-16 px-6 bg-slate-50 border border-slate-100 rounded-3xl focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary outline-none transition-all font-bold text-slate-700 ltr" 
              placeholder="https://your-server.com/webhook"
            />
          </div>

          <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 space-y-4">
            <h3 className="font-bold text-slate-700 flex items-center gap-2">
              <RefreshCcw size={18} />
              מידע על המבנה הנשלח
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              המערכת שולחת בקשת <span className="font-mono bg-slate-200 px-1 rounded text-slate-800">POST</span> עם גוף הודעה בפורמט JSON הכולל את שם האירוע (<span className="font-mono">event</span>), חותמת זמן (<span className="font-mono">timestamp</span>) ואת כל נתוני הבקשה הרלוונטית (<span className="font-mono">data</span>).
            </p>
          </div>

          <div className="flex items-center gap-4 pt-4">
            <button 
              type="submit" 
              disabled={isSaving}
              className="flex-1 h-16 bg-primary text-white font-black rounded-3xl shadow-xl shadow-primary-100 flex items-center justify-center gap-3 hover:bg-primary-600 transition-all disabled:opacity-50"
            >
              {isSaving ? <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Save size={20} />}
              שמור הגדרות
            </button>
            <button 
              type="button"
              onClick={testWebhook}
              disabled={!webhookUrl || isSaving}
              className="px-10 h-16 bg-white text-slate-600 font-bold rounded-3xl border border-slate-200 hover:bg-slate-50 transition-all disabled:opacity-30"
            >
              בצע בדיקה
            </button>
          </div>

          {status === 'success' && (
            <div className="flex items-center gap-3 text-emerald-600 bg-emerald-50 p-4 rounded-2xl font-bold border border-emerald-100 animate-in slide-in-from-top-2">
              <CheckCircle size={20} />
              ההגדרות נשמרו בהצלחה!
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default SettingsAdmin;
