
import React, { useState, useEffect } from 'react';
import { INITIAL_PROFILES, INITIAL_DEPARTMENTS } from '../../mockData';
import { Profile, UserRole } from '../../types';
import { UserPlus, Search, Edit2, Shield, Trash2, X, Lock, Mail, Users, Calendar, Phone, Eye, EyeOff } from 'lucide-react';

const UsersAdmin: React.FC = () => {
  const [users, setUsers] = useState<Profile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<Profile | null>(null);
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});
  
  // Form State
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('employee');
  const [dept, setDept] = useState('');
  const [phone, setPhone] = useState('');
  const [approverId, setApproverId] = useState('');
  const [calendarEmailsStr, setCalendarEmailsStr] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    const saved = localStorage.getItem('zabilo_users');
    if (saved) {
      setUsers(JSON.parse(saved));
    } else {
      setUsers(INITIAL_PROFILES);
      localStorage.setItem('zabilo_users', JSON.stringify(INITIAL_PROFILES));
    }
  }, []);

  const saveUsers = (updatedUsers: Profile[]) => {
    setUsers(updatedUsers);
    localStorage.setItem('zabilo_users', JSON.stringify(updatedUsers));
  };

  const filteredUsers = users.filter(u => 
    u.full_name.includes(searchTerm) || 
    u.username.includes(searchTerm) || 
    u.email?.includes(searchTerm)
  );

  const handleOpenModal = (user?: Profile) => {
    if (user) {
      setEditingUser(user);
      setUsername(user.username);
      setFullName(user.full_name);
      setEmail(user.email || '');
      setRole(user.role);
      setDept(user.department_id || '');
      setPhone(user.phone || '');
      setApproverId(user.approver_id || '');
      setCalendarEmailsStr(user.calendar_emails.join(', '));
      // In the admin list, the password_hash IS the password for this local demo
      setPassword(user.password_hash || '');
    } else {
      setEditingUser(null);
      resetForm();
    }
    setIsModalOpen(true);
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    const calendarEmails = calendarEmailsStr.split(',').map(e => e.trim()).filter(e => e !== '');

    if (editingUser) {
      const updated = users.map(u => u.id === editingUser.id ? {
        ...u, 
        username, 
        full_name: fullName, 
        email, 
        role, 
        department_id: dept, 
        phone,
        approver_id: approverId || null, 
        calendar_emails: calendarEmails,
        password_hash: password || u.password_hash
      } : u);
      saveUsers(updated);
    } else {
      const newUser: Profile = {
        id: Math.random().toString(36).substr(2, 9),
        username, 
        full_name: fullName, 
        email, 
        role, 
        department_id: dept, 
        phone,
        approver_id: approverId || null, 
        calendar_emails: calendarEmails,
        password_hash: password || '123456'
      };
      saveUsers([...users, newUser]);
    }
    setIsModalOpen(false);
    resetForm();
  };

  const handleDelete = (id: string) => {
    if (confirm('האם אתה בטוח שברצונך למחוק משתמש זה?')) {
      saveUsers(users.filter(u => u.id !== id));
    }
  };

  const resetForm = () => {
    setUsername(''); 
    setFullName(''); 
    setEmail(''); 
    setRole('employee'); 
    setDept('');
    setPhone(''); 
    setApproverId(''); 
    setCalendarEmailsStr(''); 
    setPassword('');
  };

  const togglePasswordVisibility = (userId: string) => {
    setShowPasswords(prev => ({ ...prev, [userId]: !prev[userId] }));
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight">ניהול עובדים</h1>
          <p className="text-slate-500 font-medium mt-2">הוספה, עריכה וניהול הרשאות לצוות הארגוני.</p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="bg-primary text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-2 hover:bg-primary-600 transition-all shadow-xl shadow-primary-100"
        >
          <UserPlus size={22} />
          הוסף עובד
        </button>
      </div>

      <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="text" 
            placeholder="חפש לפי שם, אימייל או שם משתמש..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pr-14 pl-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:bg-white focus:ring-4 focus:ring-primary-500/10 transition-all font-medium"
          />
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-[32px] overflow-hidden shadow-xl shadow-slate-200/20">
        <table className="w-full text-right">
          <thead>
            <tr className="bg-slate-50/50 border-b border-slate-100">
              <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">שם מלא ואימייל</th>
              <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">שם משתמש</th>
              <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">סיסמה</th>
              <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">תפקיד</th>
              <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">מאשר בקשות</th>
              <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-left">ניהול</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {filteredUsers.map(user => (
              <tr key={user.id} className="group hover:bg-slate-50/40 transition-colors">
                <td className="px-8 py-5">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary-50 border border-primary-100 flex items-center justify-center font-black text-primary">
                      {user.full_name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">{user.full_name}</p>
                      <p className="text-[10px] text-slate-400 font-medium">{user.email || 'אין אימייל'}</p>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-5 text-sm font-semibold text-slate-500">{user.username}</td>
                <td className="px-8 py-5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono bg-slate-100 px-2 py-1 rounded border border-slate-200 text-slate-600">
                      {showPasswords[user.id] ? user.password_hash : '••••••••'}
                    </span>
                    <button 
                      onClick={() => togglePasswordVisibility(user.id)}
                      className="text-slate-400 hover:text-primary transition-colors"
                    >
                      {showPasswords[user.id] ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                </td>
                <td className="px-8 py-5">
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black border ${user.role === 'admin' ? 'bg-primary-50 text-primary-700 border-primary-100' : 'bg-slate-50 text-slate-700 border-slate-100'}`}>
                    <Shield size={12} />
                    {user.role === 'admin' ? 'אדמין' : 'עובד'}
                  </span>
                </td>
                <td className="px-8 py-5 text-slate-600 font-medium">
                  <div className="flex items-center gap-2">
                    <Users size={14} className="text-slate-300" />
                    <span className="text-xs">
                      {users.find(u => u.id === user.approver_id)?.full_name || 'טרם הוגדר'}
                    </span>
                  </div>
                </td>
                <td className="px-8 py-5 text-left">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => handleOpenModal(user)} className="p-2.5 hover:bg-primary-50 rounded-xl text-primary-400 hover:text-primary transition-all" title="ערוך משתמש"><Edit2 size={18} /></button>
                    <button onClick={() => handleDelete(user.id)} className="p-2.5 hover:bg-rose-50 rounded-xl text-rose-300 hover:text-rose-600 transition-all" title="מחק משתמש"><Trash2 size={18} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-2xl rounded-[40px] shadow-2xl animate-in zoom-in-95 duration-200 overflow-hidden border border-slate-100">
            <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h3 className="text-2xl font-black text-slate-900">{editingUser ? 'עריכת עובד' : 'הוספת עובד חדש'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-200/50 rounded-full text-slate-400">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveUser} className="p-8 space-y-6 max-h-[75vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-500 px-1 uppercase tracking-wider">שם מלא</label>
                  <input type="text" required value={fullName} onChange={(e) => setFullName(e.target.value)} className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary outline-none transition-all font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-500 px-1 uppercase tracking-wider">אימייל אישי</label>
                  <div className="relative">
                    <Mail className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full pr-12 pl-4 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary outline-none transition-all font-bold" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-500 px-1 uppercase tracking-wider">שם משתמש</label>
                  <input type="text" required value={username} onChange={(e) => setUsername(e.target.value)} className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary outline-none transition-all font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-500 px-1 uppercase tracking-wider">סיסמה</label>
                  <div className="relative">
                    <Lock className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input type="text" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full pr-12 pl-4 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary outline-none transition-all font-bold" placeholder={editingUser ? "עדכן סיסמה" : "ברירת מחדל: 123456"} />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-500 px-1 uppercase tracking-wider">תפקיד</label>
                  <select value={role} onChange={(e) => setRole(e.target.value as UserRole)} className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary outline-none transition-all font-bold">
                    <option value="employee">עובד</option>
                    <option value="admin">אדמין</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-500 px-1 uppercase tracking-wider">מחלקה</label>
                  <select value={dept} onChange={(e) => setDept(e.target.value)} className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary outline-none transition-all font-bold">
                    <option value="">בחר מחלקה</option>
                    {INITIAL_DEPARTMENTS.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-500 px-1 uppercase tracking-wider">טלפון</label>
                  <div className="relative">
                    <Phone className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input type="text" value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full pr-12 pl-4 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary outline-none transition-all font-bold" placeholder="05X-XXXXXXX" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-500 px-1 uppercase tracking-wider">מנהל מאשר בקשות</label>
                  <div className="relative">
                    <Users className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <select value={approverId} onChange={(e) => setApproverId(e.target.value)} className="w-full pr-12 pl-4 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary outline-none transition-all font-bold">
                      <option value="">בחר מנהל</option>
                      {users.filter(u => u.id !== editingUser?.id).map(u => (
                        <option key={u.id} value={u.id}>{u.full_name}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-slate-500 px-1 uppercase tracking-wider flex items-center gap-2">
                  <Calendar size={14} />
                  רשימת מיילים לזימוני קלנדר (מופרדים בפסיק)
                </label>
                <textarea value={calendarEmailsStr} onChange={(e) => setCalendarEmailsStr(e.target.value)} className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary outline-none transition-all font-bold resize-none h-24" placeholder="hr@zabilo.com, manager@zabilo.com..." />
              </div>

              <div className="pt-6 flex gap-4">
                <button type="submit" className="flex-1 bg-primary text-white font-black py-4 rounded-2xl hover:bg-primary-600 shadow-xl shadow-primary-100 transition-all transform hover:-translate-y-1">
                  {editingUser ? 'עדכן עובד' : 'צור עובד'}
                </button>
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-8 bg-slate-100 text-slate-600 font-bold rounded-2xl hover:bg-slate-200 transition-all">ביטול</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UsersAdmin;
