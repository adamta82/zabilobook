
import React, { useState, useEffect } from 'react';
import { useAuth } from '../App';
import { Request, Holiday, Profile, Department } from '../types';
import { INITIAL_PROFILES, INITIAL_DEPARTMENTS } from '../mockData';
import { 
  ChevronRight, 
  ChevronLeft, 
  Calendar as CalendarIcon,
  Home,
  Palmtree,
  Clock,
  Filter,
  Users as UsersIcon,
  User as UserIcon,
  XCircle,
  Info
} from 'lucide-react';

const Dashboard: React.FC = () => {
  const { user: currentUser } = useAuth();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [requests, setRequests] = useState<Request[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  
  // Filter States
  const [selectedDept, setSelectedDept] = useState<string>('');
  const [selectedUser, setSelectedUser] = useState<string>('');

  // Comprehensive Israeli Holidays 2024-2027
  const holidays: Holiday[] = [
    // 2024
    { date: '2024-04-22', name: 'ערב פסח' },
    { date: '2024-04-23', name: 'פסח א\'' },
    { date: '2024-05-13', name: 'יום הזיכרון' },
    { date: '2024-05-14', name: 'יום העצמאות' },
    { date: '2024-06-11', name: 'ערב שבועות' },
    { date: '2024-06-12', name: 'שבועות' },
    { date: '2024-10-02', name: 'ערב ראש השנה' },
    { date: '2024-10-03', name: 'ראש השנה א\'' },
    { date: '2024-10-11', name: 'ערב יום כיפור' },
    { date: '2024-10-12', name: 'יום כיפור' },
    { date: '2024-10-16', name: 'ערב סוכות' },
    { date: '2024-10-17', name: 'סוכות א\'' },
    // 2025
    { date: '2025-04-12', name: 'ערב פסח' },
    { date: '2025-04-13', name: 'פסח א\'' },
    { date: '2025-04-30', name: 'יום הזיכרון' },
    { date: '2025-05-01', name: 'יום העצמאות' },
    { date: '2025-06-01', name: 'ערב שבועות' },
    { date: '2025-06-02', name: 'שבועות' },
    { date: '2025-09-22', name: 'ערב ראש השנה' },
    { date: '2025-09-23', name: 'ראש השנה א\'' },
    { date: '2025-10-01', name: 'ערב יום כיפור' },
    { date: '2025-10-02', name: 'יום כיפור' },
    { date: '2025-10-06', name: 'ערב סוכות' },
    { date: '2025-10-07', name: 'סוכות א\'' },
    // 2026
    { date: '2026-03-03', name: 'פורים' },
    { date: '2026-04-01', name: 'ערב פסח' },
    { date: '2026-04-02', name: 'פסח א\'' },
    { date: '2026-04-20', name: 'יום הזיכרון' },
    { date: '2026-04-21', name: 'יום העצמאות' },
    { date: '2026-05-21', name: 'ערב שבועות' },
    { date: '2026-05-22', name: 'שבועות' },
    { date: '2026-09-11', name: 'ערב ראש השנה' },
    { date: '2026-09-12', name: 'ראש השנה א\'' },
    { date: '2026-09-20', name: 'ערב יום כיפור' },
    { date: '2026-09-21', name: 'יום כיפור' },
    { date: '2026-09-25', name: 'ערב סוכות' },
    { date: '2026-09-26', name: 'סוכות א\'' },
    // 2027
    { date: '2027-03-23', name: 'פורים' },
    { date: '2027-04-21', name: 'ערב פסח' },
    { date: '2027-04-22', name: 'פסח א\'' },
    { date: '2027-05-10', name: 'יום הזיכרון' },
    { date: '2027-05-11', name: 'יום העצמאות' },
    { date: '2027-06-10', name: 'ערב שבועות' },
    { date: '2027-06-11', name: 'שבועות' },
    { date: '2027-10-01', name: 'ערב ראש השנה' },
    { date: '2027-10-02', name: 'ראש השנה א\'' },
    { date: '2027-10-10', name: 'ערב יום כיפור' },
    { date: '2027-10-11', name: 'יום כיפור' },
    { date: '2027-10-15', name: 'ערב סוכות' },
    { date: '2027-10-16', name: 'סוכות א\'' },
  ];

  useEffect(() => {
    const savedRequests = localStorage.getItem('zabilo_requests');
    if (savedRequests) {
      const all = JSON.parse(savedRequests) as Request[];
      setRequests(all);
    }

    const savedUsers = localStorage.getItem('zabilo_users');
    setUsers(savedUsers ? JSON.parse(savedUsers) : INITIAL_PROFILES);

    const savedDepts = localStorage.getItem('zabilo_departments');
    setDepartments(savedDepts ? JSON.parse(savedDepts) : INITIAL_DEPARTMENTS);
  }, [currentUser]);

  const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

  const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));

  const renderCalendar = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const totalDays = daysInMonth(year, month);
    const startDay = firstDayOfMonth(year, month);
    
    const days = [];
    
    for (let i = 0; i < startDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-32 border-b border-l border-slate-100 bg-slate-50/10" />);
    }

    for (let day = 1; day <= totalDays; day++) {
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const isToday = new Date().toDateString() === new Date(year, month, day).toDateString();
      const holiday = holidays.find(h => h.date === dateStr);
      
      const dayOfWeek = new Date(year, month, day).getDay();
      const isSaturday = dayOfWeek === 6;
      const isFriday = dayOfWeek === 5;
      const isWeekend = isFriday || isSaturday;
      
      const dayRequests = requests.filter(r => {
        // Only show WFH and Vacation on the calendar
        if (r.request_type !== 'WFH' && r.request_type !== 'Vacation') return false;

        const start = new Date(r.start_date);
        start.setHours(0,0,0,0);
        const end = new Date(r.end_date);
        end.setHours(23,59,59,999);
        const current = new Date(year, month, day);
        
        const dateMatch = current >= start && current <= end && r.status !== 'rejected' && r.status !== 'cancelled';
        if (!dateMatch) return false;

        const userProfile = users.find(u => u.id === r.user_id);
        const deptMatch = !selectedDept || userProfile?.department_id === selectedDept;
        const userMatch = !selectedUser || r.user_id === selectedUser;
        return deptMatch && userMatch;
      });

      days.push(
        <div key={day} className={`h-32 border-b border-l border-slate-100 p-2.5 transition-all hover:bg-slate-50 relative group ${isWeekend ? 'bg-slate-50/40' : ''} ${holiday ? 'bg-rose-50/20' : ''}`}>
          <div className="flex justify-between items-start">
            <span className={`text-xs font-bold transition-all ${
              isToday 
                ? 'bg-primary text-white w-7 h-7 flex items-center justify-center rounded-full shadow-lg shadow-primary-200' 
                : (holiday || isSaturday) ? 'text-rose-600 font-black' : 'text-slate-500'
            }`}>
              {day}
            </span>
            {holiday && (
              <span className="text-[9px] bg-rose-100 text-rose-700 px-2 py-0.5 rounded-full font-black border border-rose-200 shadow-sm animate-in fade-in zoom-in duration-300">
                {holiday.name}
              </span>
            )}
          </div>
          
          <div className="mt-2.5 space-y-1 overflow-y-auto max-h-[75px] custom-scrollbar">
            {dayRequests.map(req => (
              <div 
                key={req.id} 
                className={`text-[9px] px-2 py-1 rounded-lg border truncate shadow-sm flex items-center gap-1.5 transition-transform hover:scale-[1.02] ${
                  req.request_type === 'WFH' 
                    ? 'bg-primary-50 border-primary-100 text-primary-700' 
                    : 'bg-emerald-50 border-emerald-100 text-emerald-700'
                } ${req.status === 'pending' ? 'opacity-70 border-dashed' : ''}`}
              >
                {req.request_type === 'WFH' ? <Home size={10} /> : <Palmtree size={10} />}
                <span className="font-bold truncate">{req.user_name}</span>
                {req.status === 'pending' && <Clock size={8} className="mr-auto text-amber-500" />}
              </div>
            ))}
          </div>
        </div>
      );
    }

    return days;
  };

  const monthNames = ["ינואר", "פברואר", "מרץ", "אפריל", "מאי", "יוני", "יולי", "אוגוסט", "ספטמבר", "אוקטובר", "נובמבר", "דצמבר"];

  const clearFilters = () => {
    setSelectedDept('');
    setSelectedUser('');
  };

  return (
    <div className="max-w-7xl mx-auto animate-in fade-in slide-in-from-bottom-2 duration-700 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-10 gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight">
            הלוח הארגוני
          </h1>
          <p className="text-slate-500 font-medium mt-2">
            מעקב אחר נוכחות וחגים לכל הצוות.
          </p>
        </div>
        
        <div className="flex items-center gap-2 bg-slate-100/80 p-1.5 rounded-2xl border border-slate-200 shadow-sm backdrop-blur-sm">
          <button onClick={prevMonth} className="p-2 hover:bg-white hover:shadow-md rounded-xl transition-all text-slate-600"><ChevronRight size={20} /></button>
          <div className="px-6 flex items-center gap-2 min-w-[160px] justify-center">
            <CalendarIcon size={18} className="text-primary" />
            <span className="font-bold text-slate-800 text-lg">{monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}</span>
          </div>
          <button onClick={nextMonth} className="p-2 hover:bg-white hover:shadow-md rounded-xl transition-all text-slate-600"><ChevronLeft size={20} /></button>
        </div>
      </div>

      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm mb-6 flex flex-wrap items-end gap-6 animate-in fade-in duration-1000">
        <div className="flex-1 min-w-[240px] space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2 px-1">
            <UsersIcon size={12} />
            סינון לפי מחלקה
          </label>
          <select 
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3.5 outline-none focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary transition-all font-bold text-slate-700 appearance-none"
          >
            <option value="">כל המחלקות</option>
            {departments.map(dept => (
              <option key={dept.id} value={dept.id}>{dept.name}</option>
            ))}
          </select>
        </div>

        <div className="flex-1 min-w-[240px] space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2 px-1">
            <UserIcon size={12} />
            סינון לפי עובד
          </label>
          <select 
            value={selectedUser}
            onChange={(e) => setSelectedUser(e.target.value)}
            className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3.5 outline-none focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary transition-all font-bold text-slate-700 appearance-none"
          >
            <option value="">כל העובדים</option>
            {users
              .filter(u => !selectedDept || u.department_id === selectedDept)
              .map(u => (
                <option key={u.id} value={u.id}>{u.full_name}</option>
              ))}
          </select>
        </div>

        {(selectedDept || selectedUser) && (
          <button 
            onClick={clearFilters}
            className="h-[54px] px-6 bg-rose-50 text-rose-600 rounded-2xl font-bold flex items-center gap-2 hover:bg-rose-100 transition-all border border-rose-100"
          >
            <XCircle size={18} />
            נקה סינונים
          </button>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-6 mb-8 px-4 py-3 bg-slate-50/50 rounded-2xl border border-slate-100 animate-in fade-in duration-1000">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
          <Info size={14} className="text-slate-300" />
          מקרא:
        </div>
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-lg bg-primary-50 border border-primary-100 flex items-center justify-center text-primary">
            <Home size={10} />
          </div>
          <span className="text-xs font-bold text-slate-600">עבודה מהבית</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-lg bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600">
            <Palmtree size={10} />
          </div>
          <span className="text-xs font-bold text-slate-600">חופשה</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-lg bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600">
            <Clock size={10} />
          </div>
          <span className="text-xs font-bold text-slate-600">ממתין לאישור</span>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-[40px] overflow-hidden shadow-2xl shadow-slate-200/40">
        <div className="grid grid-cols-7 text-center bg-slate-50/50 border-b border-slate-100 py-5">
          {["ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת"].map(d => (
            <div key={d} className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7">
          {renderCalendar()}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
