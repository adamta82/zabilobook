
import React, { useState, useEffect } from 'react';
import { 
  INITIAL_ARTICLES, 
  INITIAL_ANNOUNCEMENTS, 
  INITIAL_CATEGORIES, 
  INITIAL_FAQS 
} from '../mockData';
import { 
  Search, 
  Bookmark, 
  Star, 
  Eye, 
  Clock, 
  ChevronLeft, 
  Info,
  ChevronDown,
  ChevronUp,
  Bell
} from 'lucide-react';

const KnowledgeCenter: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [activeFaq, setActiveFaq] = useState<string | null>(null);

  const filteredArticles = INITIAL_ARTICLES.filter(a => 
    (a.title.includes(searchTerm) || a.content.includes(searchTerm)) &&
    (!selectedCategory || a.category_id === selectedCategory)
  );

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Search & Hero */}
      <section className="bg-gradient-to-l from-blue-700 to-indigo-600 rounded-3xl p-8 md:p-12 text-white shadow-xl shadow-blue-200/50 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32 blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-400/20 rounded-full -ml-32 -mb-32 blur-3xl"></div>
        
        <div className="relative z-10 text-center space-y-6">
          <h1 className="text-3xl md:text-5xl font-bold tracking-tight">ברוכים הבאים למרכז הידע</h1>
          <p className="text-blue-100 text-lg md:text-xl max-w-2xl mx-auto">כל מה שצריך לדעת על העבודה ב-Zabilo, נהלים, מדריכים ועדכונים שוטפים.</p>
          
          <div className="max-w-2xl mx-auto relative group">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-600 transition-colors" size={24} />
            <input
              type="text"
              placeholder="חפש מאמרים, מדריכים או שאלות..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full h-14 pr-14 pl-6 rounded-2xl bg-white text-slate-900 border-none shadow-lg focus:ring-4 focus:ring-blue-500/20 transition-all text-lg"
            />
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Feed */}
        <div className="lg:col-span-2 space-y-8">
          {/* Categories */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-full whitespace-nowrap transition-all ${!selectedCategory ? 'bg-blue-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:border-blue-300'}`}
            >
              הכל
            </button>
            {INITIAL_CATEGORIES.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-full whitespace-nowrap transition-all ${selectedCategory === cat.id ? 'bg-blue-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:border-blue-300'}`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          {/* Featured/Articles List */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Star size={20} className="text-yellow-500 fill-yellow-500" />
                מאמרים נבחרים
              </h2>
            </div>
            
            <div className="grid gap-4">
              {filteredArticles.map(article => (
                <div key={article.id} className="bg-white border border-slate-200 p-6 rounded-2xl hover:shadow-md transition-all group cursor-pointer">
                  <div className="flex items-start justify-between mb-3">
                    <span className="px-2.5 py-1 rounded-md bg-blue-50 text-blue-600 text-xs font-semibold">
                      {INITIAL_CATEGORIES.find(c => c.id === article.category_id)?.name}
                    </span>
                    <div className="flex items-center gap-3 text-slate-400 text-sm">
                      <span className="flex items-center gap-1"><Eye size={14} /> {article.view_count}</span>
                      <span className="flex items-center gap-1"><Clock size={14} /> {new Date(article.published_at).toLocaleDateString('he-IL')}</span>
                    </div>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors mb-2">{article.title}</h3>
                  <p className="text-slate-600 text-sm line-clamp-2 leading-relaxed">{article.summary}</p>
                  <div className="mt-4 flex items-center gap-2 text-blue-600 font-medium text-sm">
                    קרא עוד
                    <ChevronLeft size={16} />
                  </div>
                </div>
              ))}
              {filteredArticles.length === 0 && (
                <div className="text-center py-12 bg-slate-100 rounded-2xl text-slate-500 italic">
                  לא נמצאו מאמרים התואמים את החיפוש.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-8">
          {/* Announcements */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
              <h2 className="font-bold flex items-center gap-2">
                <Bell size={18} className="text-blue-600" />
                עדכונים
              </h2>
            </div>
            <div className="p-4 space-y-4">
              {INITIAL_ANNOUNCEMENTS.map(ann => (
                <div key={ann.id} className="p-4 rounded-xl bg-blue-50/50 border border-blue-100">
                  <div className="flex items-center gap-2 mb-2">
                    {ann.is_pinned && <Bookmark size={14} className="text-blue-600 fill-blue-600" />}
                    <h4 className="font-bold text-slate-900 text-sm">{ann.title}</h4>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed mb-3">{ann.content}</p>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-medium">
                    <span>פורסם ע"י {ann.author_name}</span>
                    <span>{new Date(ann.created_at).toLocaleDateString('he-IL')}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* FAQ Accordion */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <div className="bg-slate-50 px-6 py-4 border-b border-slate-200">
              <h2 className="font-bold flex items-center gap-2">
                <Info size={18} className="text-indigo-600" />
                שאלות ותשובות
              </h2>
            </div>
            <div className="divide-y divide-slate-100">
              {INITIAL_FAQS.map(faq => (
                <div key={faq.id} className="p-2">
                  <button 
                    onClick={() => setActiveFaq(activeFaq === faq.id ? null : faq.id)}
                    className="w-full flex items-center justify-between p-3 text-right hover:bg-slate-50 rounded-lg transition-colors group"
                  >
                    <span className="text-sm font-medium text-slate-800 group-hover:text-blue-600">{faq.question}</span>
                    {activeFaq === faq.id ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  </button>
                  {activeFaq === faq.id && (
                    <div className="px-4 py-3 text-xs text-slate-600 leading-relaxed animate-in slide-in-from-top-2">
                      {faq.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KnowledgeCenter;
