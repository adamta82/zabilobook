
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../App';
import { ShieldAlert, User, Lock, ArrowLeft } from 'lucide-react';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const { login, user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) navigate('/');
  }, [user, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    const success = await login(username, password);
    if (success) {
      navigate('/');
    } else {
      setError('שם משתמש או סיסמה שגויים');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-white relative overflow-hidden" dir="rtl">
      {/* Stripe-like background decor */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-primary-50/50 rounded-full -mr-96 -mt-96 blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-slate-50 rounded-full -ml-96 -mb-96 blur-3xl"></div>

      <div className="w-full max-w-md space-y-8 relative z-10 animate-in fade-in zoom-in-95 duration-700">
        <div className="text-center space-y-4">
          <img 
            src="https://raw.githubusercontent.com/Zabilo/assets/main/logo.png" 
            alt="Zabilo Logo" 
            className="w-64 mx-auto mb-2 transform hover:scale-105 transition-transform duration-500"
            onError={(e) => {
              // Fallback if image path is not yet correct in the environment
              e.currentTarget.style.display = 'none';
              e.currentTarget.parentElement!.innerHTML += '<div class="inline-flex items-center justify-center w-20 h-20 bg-primary rounded-2xl text-white shadow-2xl font-black text-4xl mx-auto mb-6">Z</div><h1 class="text-5xl font-black text-slate-900 tracking-tighter">Zabilo</h1>';
            }}
          />
          <p className="text-slate-400 font-bold text-sm uppercase tracking-[0.3em]">מערכת ניהול פנים ארגונית</p>
        </div>

        <div className="bg-white p-10 rounded-[40px] shadow-2xl shadow-slate-200/60 border border-slate-100">
          <form onSubmit={handleLogin} className="space-y-8">
            <div className="space-y-2">
              <label className="text-xs font-black text-slate-500 uppercase tracking-widest mr-1 block">שם משתמש</label>
              <div className="relative group">
                <User className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-primary transition-colors" size={20} />
                <input
                  type="text" required value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full h-14 pr-14 pl-4 bg-slate-50 border border-slate-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary outline-none transition-all font-bold text-slate-700"
                  placeholder="username"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-black text-slate-500 uppercase tracking-widest mr-1 block">סיסמה</label>
              <div className="relative group">
                <Lock className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-primary transition-colors" size={20} />
                <input
                  type="password" required value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full h-14 pr-14 pl-4 bg-slate-50 border border-slate-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-primary-500/10 focus:border-primary outline-none transition-all font-bold text-slate-700"
                  placeholder="••••••••"
                />
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-rose-600 bg-rose-50 p-4 rounded-2xl text-sm font-bold border border-rose-100 animate-in shake duration-300">
                <ShieldAlert size={18} />
                {error}
              </div>
            )}

            <button
              type="submit" disabled={isLoading}
              className="w-full h-16 bg-primary hover:bg-primary-600 text-white font-black rounded-2xl shadow-xl shadow-primary-100 transition-all flex items-center justify-center gap-3 group disabled:opacity-70 hover:-translate-y-1 active:scale-95"
            >
              {isLoading ? (
                <div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  כניסה למערכת
                  <ArrowLeft size={20} className="group-hover:-translate-x-2 transition-transform" />
                </>
              )}
            </button>
          </form>

          <div className="mt-10 pt-8 border-t border-slate-50 text-center">
            <p className="text-xs text-slate-300 font-medium italic">
              Zabilo Book v2.5 • לשימוש פנימי בלבד
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
