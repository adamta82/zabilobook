
import React, { useState, useEffect } from 'react';
import { useAuth } from '../App';
import { Request, RequestType, RequestStatus, WFHTask, RequestItem, Profile, Department, AppSettings } from '../types';
import { 
  Plus, 
  Home, 
  Palmtree, 
  X,
  CheckCircle2,
  Clock,
  Trash2,
  Calendar as CalendarIcon,
  Briefcase,
  PlusCircle,
  Package,
  ShoppingCart,
  ShieldCheck,
  Truck,
  Box,
  Check,
  Eye,
  Info,
  User,
  ExternalLink,
  Settings2,
  RotateCcw
} from 'lucide-react';

const Requests: React.FC = () => {
  const { user } = useAuth();
  const [requests, setRequests] = useState<Request[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [viewingRequest, setViewingRequest] = useState<Request | null>(null);
  
  // Form State
  const [reqType, setReqType] = useState<RequestType>('WFH');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [isSingleDay, setIsSingleDay] = useState(false);
  const [reason, setReason] = useState('');
  const [details, setDetails] = useState('');
  const [tasks, setTasks] = useState<WFHTask[]>([{ id: '1', name: '', hours: 0, referent: '' }]);
  const [items, setItems] = useState<RequestItem[]>([{ id: '1', name: '', quantity: 1 }]);
  
  // WFH Checklist State
  const [wfhChecklist, setWfhChecklist] = useState({
    environment: false,
    internet: false,
    computer: false,
    plan: false
  });

  const getVisibleRequests = (allRequests: Request[]) => {
    if (!user) return [];
    return allRequests;
  };

  useEffect(() => {
    const saved = localStorage.getItem('zabilo_requests');
    if (saved) {
      const all = JSON.parse(saved) as Request[];
      setRequests(getVisibleRequests(all));
    }
  }, [user]);

  const triggerWebhook = async (event: string, request: Request) => {
    const savedSettings = localStorage.getItem('zabilo_settings');
    if (!savedSettings) return;

    const settings: AppSettings = JSON.parse(savedSettings);
    if (!settings.webhook_url) return;

    try {
      // Get profiles for enrichment
      const savedUsers = localStorage.getItem('zabilo_users');
      const users: Profile[] = savedUsers ? JSON.parse(savedUsers) : [];
      const requestUser = users.find(u => u.id === request.user_id);
      const approver = users.find(u => u.id === requestUser?.approver_id);
      
      const enrichedData = {
        ...request,
        approver_email: approver?.email || null,
        calendar_emails: requestUser?.calendar_emails || []
      };

      await fetch(settings.webhook_url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event,
          timestamp: new Date().toISOString(),
          data: enrichedData
        })
      });
    } catch (e) {
      console.error('Webhook trigger failed:', e);
    }
  };

  const addTask = () => setTasks([...tasks, { id: Math.random().toString(), name: '', hours: 0, referent: '' }]);
  const removeTask = (id: string) => tasks.length > 1 && setTasks(tasks.filter(t => t.id !== id));
  const updateTask = (id: string, field: keyof WFHTask, value: any) => setTasks(tasks.map(t => t.id === id ? { ...t, [field]: value } : t));
  
  const addItem = () => setItems([...items, { id: Math.random().toString(), name: '', quantity: 1 }]);
  const removeItem = (id: string) => items.length > 1 && setItems(items.filter(i => i.id !== id));
  const updateItem = (id: string, field: keyof RequestItem, value: any) => setItems(items.map(i => i.id === id ? { ...i, [field]: value } : i));

  const totalHours = tasks.reduce((sum, t) => sum + Number(t.hours || 0), 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (reqType === 'WFH' && !Object.values(wfhChecklist).every(v => v)) {
      alert('יש לאשר את כל סעיפי נוהל עבודה מהבית.');
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    const finalStartDate = (reqType === 'Equipment' || reqType === 'Supplies') ? today : startDate;
    const finalEndDate = (reqType === 'WFH' || (reqType === 'Vacation' && isSingleDay) || reqType === 'Equipment' || reqType === 'Supplies') ? finalStartDate : endDate;

    const newReq: Request = {
      id: Math.random().toString(36).substr(2, 9),
      user_id: user?.id || '',
      user_name: user?.full_name || '',
      request_type: reqType,
      status: 'pending',
      start_date: finalStartDate,
      end_date: finalEndDate,
      reason: (reqType === 'Equipment' || reqType === 'Supplies') ? '' : reason,
      details: (reqType === 'Equipment' || reqType === 'Supplies') ? items.map(i => `${i.name} (${i.quantity})`).join(', ') : details,
      tasks: reqType === 'WFH' ? tasks : undefined,
      items: (reqType === 'Equipment' || reqType === 'Supplies') ? items : undefined,
      total_hours: reqType === 'WFH' ? totalHours : undefined,
      created_at: new Date().toISOString()
    };

    const allSaved = localStorage.getItem('zabilo_requests');
    const updatedAll = [newReq, ...(allSaved ? JSON.parse(allSaved) : [])];
    localStorage.setItem('zabilo_requests', JSON.stringify(updatedAll));
    
    setRequests(getVisibleRequests(updatedAll));
    setIsModalOpen(false);
    triggerWebhook('request_created', newReq);
    resetForm();
  };

  const resetForm = () => {
    setReqType('WFH');
    setStartDate(new Date().toISOString().split('T')[0]);
    setEndDate(new Date().toISOString().split('T')[0]);
    setIsSingleDay(false);
    setReason('');
    setDetails('');
    setTasks([{ id: '1', name: '', hours: 0, referent: '' }]);
    setItems([{ id: '1', name: '', quantity: 1 }]);
    setWfhChecklist({ environment: false, internet: false, computer: false, plan: false });
  };

  const updateStatus = (reqId: string, newStatus: RequestStatus) => {
    if (newStatus !== 'cancelled' && user?.role !== 'admin') return;
    const allSaved = localStorage.getItem('zabilo_requests');
    if (allSaved) {
      const all = JSON.parse(allSaved) as Request[];
      let triggeredRequest: Request | null = null;

      const updatedAll = all.map(r => {
        if (r.id === reqId) {
          const updated = { 
            ...r, 
            status: newStatus,
            approved_by: user?.full_name,
            approved_at: new Date().toISOString()
          };
          triggeredRequest = updated;
          return updated;
        }
        return r;
      });

      localStorage.setItem('zabilo_requests', JSON.stringify(updatedAll));
      setRequests(getVisibleRequests(updatedAll));
      
      // Update viewing request if open
      if (viewingRequest && viewingRequest.id === reqId) {
        setViewingRequest(prev => prev ? { ...prev, status: newStatus, approved_by: user?.full_name, approved_at: new Date().toISOString() } : null);
      }

      if (triggeredRequest) {
        if (newStatus === 'approved') triggerWebhook('request_approved', triggeredRequest);
        else if (newStatus === 'rejected') triggerWebhook('request_rejected', triggeredRequest);
        else triggerWebhook('request_status_changed', triggeredRequest);
      }
    }
  };

  const getStatusLabel = (s: RequestStatus) => {
    switch (s) {
      case 'pending': return 'ממתין';
      case 'approved': return 'אושר';
      case 'rejected': return 'נדחה';
      case 'ordered': return 'הוזמן';
      case 'supplied': return 'סופק';
      case 'cancelled': return 'בוטל';
      default: return s;
    }
  };

  const getStatusBadgeStyles = (s: RequestStatus) => {
    switch (s) {
      case 'pending': return 'bg-amber-50 text-amber-700 border-amber-100';
      case 'approved': return 'bg-emerald-50 text-emerald-700 border-emerald-100';
      case 'rejected': return 'bg-rose-50 text-rose-700 border-rose-100';
      case 'ordered': return 'bg-blue-50 text-blue-700 border-blue-100';
      case 'supplied': return 'bg-indigo-50 text-indigo-700 border-indigo-100';
      case 'cancelled': return 'bg-slate-50 text-slate-500 border-slate-100';
      default: return 'bg-slate-50 text-slate-500 border-slate-100';
    }
  };

  const getRequestIcon = (t: RequestType) => {
    switch (t) {
      case 'WFH': return <Home size={22} />;
      case 'Vacation': return <Palmtree size={22} />;
      case 'Equipment': return <Package size={22} />;
      case 'Supplies': return <ShoppingCart size={22} />;
    }
  };

  const getRequestTypeName = (t: RequestType) => {
    switch (t) {
      case 'WFH': return 'עבודה מהבית';
      case 'Vacation': return 'חופשה';
      case 'Equipment': return 'ציוד משרדי';
      case 'Supplies': return 'מצרכים';
    }
  };

  const renderAdminStatusButtons = (req: Request) => {
    const isLogistics = req.request_type === 'Equipment' || req.request_type === 'Supplies';
    const baseStatuses: RequestStatus[] = ['pending', 'approved', 'rejected', 'cancelled'];
    const logisticStatuses: RequestStatus[] = ['ordered', 'supplied'];
    const allOptions = isLogistics ? [...baseStatuses, ...logisticStatuses] : baseStatuses;

    return (
      <div className="flex flex-wrap gap-2">
        {allOptions.map(status => {
          const isActive = req.status === status;
          return (
            <button
              key={status}
              type="button"
              onClick={() => updateStatus(req.id, status)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 ${
                isActive 
                  ? 'bg-primary text-white border-primary shadow-md shadow-primary-100' 
                  : 'bg-white text-slate-500 border-slate-100 hover:bg-slate-50'
              }`}
            >
              {status === 'pending' && <RotateCcw size={14} />}
              {status === 'approved' && <CheckCircle2 size={14} />}
              {status === 'rejected' && <X size={14} />}
              {status === 'ordered' && <Truck size={14} />}
              {status === 'supplied' && <Box size={14} />}
              {status === 'cancelled' && <Trash2 size={14} />}
              {getStatusLabel(status)}
            </button>
          );
        })}
      </div>
    );
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10 animate-in slide-in-from-bottom-2 duration-700 pb-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight">ניהול בקשות</h1>
          <p className="text-slate-500 font-medium mt-2">מעקב וניהול בקשות עובדים בארגון.</p>
        </div>
        <button
          onClick={() => { resetForm(); setIsModalOpen(true); }}
          className="bg-primary text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-2 hover:bg-primary-600 transition-all shadow-xl shadow-primary-200/50"
        >
          <PlusCircle size={22} />
          בקשה חדשה
        </button>
      </div>

      <div className="bg-white border border-slate-200 rounded-[32px] overflow-hidden shadow-xl shadow-slate-200/20">
        <table className="w-full text-right">
          <thead>
            <tr className="bg-slate-50/50 border-b border-slate-100">
              <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">סוג הבקשה</th>
              <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">עובד</th>
              <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">תאריכים/פרטים</th>
              <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">סטטוס</th>
              <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-left">ניהול</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {requests.map(req => (
              <tr 
                key={req.id} 
                className="group hover:bg-slate-50/40 transition-colors cursor-pointer"
                onClick={() => setViewingRequest(req)}
              >
                <td className="px-10 py-5">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-2xl ${
                      req.request_type === 'WFH' ? 'bg-primary-50 text-primary-600' : 
                      req.request_type === 'Vacation' ? 'bg-emerald-50 text-emerald-600' :
                      req.request_type === 'Equipment' ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'
                    }`}>
                      {getRequestIcon(req.request_type)}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-900">{getRequestTypeName(req.request_type)}</p>
                      {req.total_hours && <p className="text-[10px] text-primary-500 font-bold uppercase mt-0.5">{req.total_hours} שעות משימה</p>}
                    </div>
                  </div>
                </td>
                <td className="px-10 py-5">
                  <span className="text-sm font-semibold text-slate-700">{req.user_name}</span>
                </td>
                <td className="px-10 py-5">
                  <div className="flex flex-col gap-1 text-sm text-slate-500 font-medium text-center">
                    {(req.request_type === 'WFH' || req.request_type === 'Vacation') ? (
                      <div className="flex items-center justify-center gap-2"><CalendarIcon size={14} className="text-slate-300" /> {req.start_date} {req.end_date !== req.start_date ? `עד ${req.end_date}` : ''}</div>
                    ) : (
                      <div className="text-xs text-slate-400 italic">בקשה לוגיסטית</div>
                    )}
                    <p className="text-xs truncate max-w-[200px] mx-auto">{req.details || req.reason}</p>
                  </div>
                </td>
                <td className="px-10 py-5">
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-black border ${getStatusBadgeStyles(req.status)}`}>
                    {getStatusLabel(req.status)}
                  </span>
                </td>
                <td className="px-10 py-5 text-left" onClick={e => e.stopPropagation()}>
                  <div className="flex justify-end gap-2">
                    <button 
                      onClick={() => setViewingRequest(req)} 
                      className="bg-slate-100 text-slate-500 p-2 rounded-xl hover:bg-slate-200 transition-all"
                      title="צפה בפרטים"
                    >
                      <Eye size={16} />
                    </button>
                    {req.status === 'pending' && (user?.role === 'admin' || req.user_id === user?.id) && (
                      <button onClick={() => updateStatus(req.id, 'cancelled')} className="bg-slate-100 text-slate-400 p-2 rounded-xl hover:bg-slate-200 shadow-md" title="בטל בקשה"><Trash2 size={16} /></button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Full Details View Modal */}
      {viewingRequest && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-2xl rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 border border-slate-100">
            <div className="p-10 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-4">
                <div className={`p-4 rounded-3xl ${
                  viewingRequest.request_type === 'WFH' ? 'bg-primary-50 text-primary-600' : 
                  viewingRequest.request_type === 'Vacation' ? 'bg-emerald-50 text-emerald-600' :
                  viewingRequest.request_type === 'Equipment' ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'
                }`}>
                  {getRequestIcon(viewingRequest.request_type)}
                </div>
                <div>
                  <h3 className="text-2xl font-black text-slate-900 leading-tight">פרטי בקשה #{viewingRequest.id}</h3>
                  <p className="text-slate-400 font-bold text-sm uppercase tracking-wider">{getRequestTypeName(viewingRequest.request_type)}</p>
                </div>
              </div>
              <button onClick={() => setViewingRequest(null)} className="p-3 hover:bg-slate-200/50 rounded-full text-slate-400"><X size={28} /></button>
            </div>
            
            <div className="p-10 space-y-8 max-h-[70vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-2 gap-8">
                <div className="space-y-1">
                  <p className="text-xs font-black text-slate-400 uppercase">עובד/ת</p>
                  <div className="flex items-center gap-2 font-black text-slate-800">
                    <User size={16} className="text-primary" />
                    {viewingRequest.user_name}
                  </div>
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-black text-slate-400 uppercase">סטטוס נוכחי</p>
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-black border ${getStatusBadgeStyles(viewingRequest.status)}`}>
                    {getStatusLabel(viewingRequest.status)}
                  </span>
                </div>
              </div>

              {/* Admin Full Management Panel */}
              {user?.role === 'admin' && (
                <div className="bg-slate-50 border border-slate-200 rounded-3xl p-6 space-y-4 shadow-inner">
                  <h4 className="text-sm font-black text-slate-700 flex items-center gap-2">
                    <Settings2 size={16} />
                    לוח בקרה לניהול סטטוס (אדמין)
                  </h4>
                  {renderAdminStatusButtons(viewingRequest)}
                </div>
              )}

              {(viewingRequest.request_type === 'WFH' || viewingRequest.request_type === 'Vacation') && (
                <div className="space-y-1">
                  <p className="text-xs font-black text-slate-400 uppercase">תקופת הבקשה</p>
                  <div className="bg-slate-50 p-4 rounded-2xl flex items-center gap-4 font-bold text-slate-700 border border-slate-100">
                    <CalendarIcon size={18} className="text-slate-400" />
                    {viewingRequest.start_date} {viewingRequest.end_date !== viewingRequest.start_date ? `עד ${viewingRequest.end_date}` : ''}
                  </div>
                </div>
              )}

              {viewingRequest.reason && (
                <div className="space-y-2">
                  <p className="text-xs font-black text-slate-400 uppercase flex items-center gap-2">
                    <Info size={14} />
                    סיבה לבקשה
                  </p>
                  <div className="bg-slate-50 p-6 rounded-3xl text-sm font-semibold text-slate-700 leading-relaxed italic border border-slate-100">
                    "{viewingRequest.reason}"
                  </div>
                </div>
              )}

              {viewingRequest.tasks && (
                <div className="space-y-4">
                  <h4 className="text-sm font-black text-slate-900 border-b border-slate-100 pb-2">לו"ז משימות ({viewingRequest.total_hours} שעות)</h4>
                  <div className="space-y-3">
                    {viewingRequest.tasks.map(t => (
                      <div key={t.id} className="flex items-center justify-between p-4 bg-white border border-slate-100 rounded-2xl shadow-sm">
                        <div>
                          <p className="font-bold text-slate-800 text-sm">{t.name}</p>
                          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">רפרנט: {t.referent}</p>
                        </div>
                        <div className="bg-primary-50 text-primary-700 font-black px-3 py-1 rounded-xl text-xs">{t.hours} ש'</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {viewingRequest.items && (
                <div className="space-y-4">
                  <h4 className="text-sm font-black text-slate-900 border-b border-slate-100 pb-2">רשימת פריטים מבוקשת</h4>
                  <div className="grid grid-cols-1 gap-2">
                    {viewingRequest.items.map(i => (
                      <div key={i.id} className="flex items-center justify-between p-4 bg-white border border-slate-100 rounded-2xl">
                        <span className="font-bold text-slate-700">{i.name}</span>
                        <span className="bg-slate-100 text-slate-600 px-3 py-1 rounded-xl font-black text-xs">כמות: {i.quantity}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {viewingRequest.approved_by && (
                <div className="mt-10 p-6 bg-emerald-50/50 border border-emerald-100 rounded-3xl">
                  <p className="text-xs font-black text-emerald-800 uppercase tracking-widest mb-2">פעולה אחרונה</p>
                  <p className="text-sm font-bold text-emerald-700">עודכן על ידי {viewingRequest.approved_by} ב-{new Date(viewingRequest.approved_at || '').toLocaleDateString('he-IL')}</p>
                </div>
              )}
            </div>
            
            <div className="p-8 bg-slate-50/80 border-t border-slate-100 flex justify-end">
              <button onClick={() => setViewingRequest(null)} className="px-8 py-3.5 bg-white text-slate-600 font-bold rounded-2xl border border-slate-200 hover:bg-slate-50 transition-all">סגור חלון</button>
            </div>
          </div>
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-3xl rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 border border-slate-100">
            <div className="p-10 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h3 className="text-3xl font-black text-slate-900 tracking-tight">בקשה חדשה</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-2.5 hover:bg-slate-200/50 rounded-full text-slate-400"><X size={28} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-10 space-y-8 max-h-[75vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                {[
                  { id: 'WFH', label: 'עבודה מהבית', icon: Home },
                  { id: 'Vacation', label: 'חופשה', icon: Palmtree },
                  { id: 'Equipment', label: 'ציוד משרדי', icon: Package },
                  { id: 'Supplies', label: 'מצרכים', icon: ShoppingCart }
                ].map((type) => (
                  <button
                    key={type.id}
                    type="button"
                    onClick={() => { 
                      setReqType(type.id as RequestType); 
                      if (type.id === 'WFH') setIsSingleDay(true);
                      else setIsSingleDay(false);
                    }}
                    className={`flex flex-col items-center justify-center gap-2 p-4 rounded-2xl border-2 transition-all font-bold ${reqType === type.id ? 'border-primary bg-primary-50 text-primary-700 shadow-md' : 'border-slate-100 bg-white text-slate-400 hover:border-slate-200'}`}
                  >
                    <type.icon size={24} />
                    <span className="text-xs">{type.label}</span>
                  </button>
                ))}
              </div>

              {reqType === 'WFH' && (
                <div className="bg-primary-50 border border-primary-100 rounded-3xl p-6 space-y-4">
                  <h4 className="flex items-center gap-2 font-black text-primary-800 text-sm"><ShieldCheck size={18} /> הנחיות עבודה מהבית</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[
                      { key: 'environment', label: 'מרחב שקט לעבודה' }, 
                      { key: 'internet', label: 'אינטרנט מאובטח' }, 
                      { key: 'computer', label: 'מחשב חברה בלבד' }, 
                      { key: 'plan', label: 'לו"ז משימות מפורט' }
                    ].map((item) => (
                      <label key={item.key} className="flex items-start gap-3 cursor-pointer group">
                        <input 
                          type="checkbox" 
                          checked={(wfhChecklist as any)[item.key]} 
                          onChange={(e) => setWfhChecklist({...wfhChecklist, [item.key]: e.target.checked})} 
                          className="mt-1 w-4 h-4 rounded border-primary-300 text-primary" 
                        />
                        <span className="text-xs text-primary-800 font-semibold">{item.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {reqType === 'Vacation' && (
                <div className="flex items-center gap-4 bg-emerald-50 border border-emerald-100 p-4 rounded-2xl">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <div className={`w-12 h-6 rounded-full relative transition-colors ${isSingleDay ? 'bg-emerald-600' : 'bg-slate-300'}`}>
                      <input 
                        type="checkbox" 
                        checked={isSingleDay} 
                        onChange={(e) => setIsSingleDay(e.target.checked)} 
                        className="sr-only" 
                      />
                      <div className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${isSingleDay ? 'translate-x-6' : 'translate-x-0'}`} />
                    </div>
                    <span className="text-sm font-bold text-emerald-900">יום חופש בודד</span>
                  </label>
                </div>
              )}

              {(reqType === 'WFH' || reqType === 'Vacation') && (
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-500 px-1">תאריך התחלה</label>
                    <input 
                      type="date" 
                      required 
                      value={startDate} 
                      onChange={(e) => setStartDate(e.target.value)} 
                      className="w-full px-5 py-4 rounded-2xl bg-slate-50 border border-slate-100 outline-none font-bold text-slate-700 focus:bg-white focus:border-primary transition-all" 
                    />
                  </div>
                  {(reqType === 'Vacation' && !isSingleDay) && (
                    <div className="space-y-2">
                      <label className="text-xs font-black text-slate-500 px-1">תאריך סיום</label>
                      <input 
                        type="date" 
                        required 
                        value={endDate} 
                        onChange={(e) => setEndDate(e.target.value)} 
                        className="w-full px-5 py-4 rounded-2xl bg-slate-50 border border-slate-100 outline-none font-bold text-slate-700 focus:bg-white focus:border-primary transition-all" 
                      />
                    </div>
                  )}
                </div>
              )}

              {(reqType !== 'Equipment' && reqType !== 'Supplies') && (
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-500 px-1">סיבה לבקשה</label>
                  <textarea 
                    value={reason} 
                    onChange={(e) => setReason(e.target.value)} 
                    className="w-full px-5 py-3 bg-slate-50 border border-slate-100 rounded-2xl outline-none font-bold h-24 focus:bg-white focus:border-primary transition-all" 
                    placeholder="פרט בקצרה..." 
                  />
                </div>
              )}

              {reqType === 'WFH' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between px-1">
                    <h4 className="text-sm font-black text-slate-800 flex items-center gap-2"><Briefcase size={18} className="text-primary" /> לו"ז משימות</h4>
                    <button type="button" onClick={addTask} className="text-xs font-bold text-primary-600 bg-primary-50 px-3 py-1.5 rounded-xl transition-all hover:bg-primary-100 flex items-center gap-1">
                      <Plus size={14} /> 
                      הוסף משימה
                    </button>
                  </div>
                  <div className="space-y-3">
                    {tasks.map((task) => (
                      <div key={task.id} className="grid grid-cols-12 gap-3 items-end bg-white p-4 rounded-2xl border border-slate-100 shadow-sm transition-all hover:border-slate-200">
                        <div className="col-span-5">
                          <input type="text" value={task.name} required onChange={(e) => updateTask(task.id, 'name', e.target.value)} className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 border-none font-semibold focus:ring-2 focus:ring-primary/20" placeholder="משימה" />
                        </div>
                        <div className="col-span-2">
                          <input type="number" value={task.hours} required min="0" step="0.5" onChange={(e) => updateTask(task.id, 'hours', e.target.value)} className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 border-none font-bold text-center focus:ring-2 focus:ring-primary/20" />
                        </div>
                        <div className="col-span-4">
                          <input type="text" value={task.referent} required onChange={(e) => updateTask(task.id, 'referent', e.target.value)} className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 border-none font-semibold focus:ring-2 focus:ring-primary/20" placeholder="רפרנט" />
                        </div>
                        <div className="col-span-1 flex justify-center pb-2">
                          <button type="button" onClick={() => removeTask(task.id)} className="text-slate-300 hover:text-rose-500 transition-colors"><Trash2 size={16} /></button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {(reqType === 'Equipment' || reqType === 'Supplies') && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between px-1">
                    <h4 className="text-sm font-black text-slate-800 flex items-center gap-2">
                      {reqType === 'Equipment' ? <Package size={18} className="text-amber-500" /> : <ShoppingCart size={18} className="text-rose-500" />}
                      רשימת פריטים
                    </h4>
                    <button type="button" onClick={addItem} className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1.5 rounded-xl transition-all hover:bg-slate-200 flex items-center gap-1">
                      <Plus size={14} /> 
                      הוסף פריט
                    </button>
                  </div>
                  <div className="space-y-3">
                    {items.map((item) => (
                      <div key={item.id} className="grid grid-cols-12 gap-3 items-end bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                        <div className="col-span-8">
                          <input type="text" value={item.name} required onChange={(e) => updateItem(item.id, 'name', e.target.value)} className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 border-none font-semibold" placeholder="שם הפריט / תיאור" />
                        </div>
                        <div className="col-span-3">
                          <input type="number" value={item.quantity} required min="1" onChange={(e) => updateItem(item.id, 'quantity', e.target.value)} className="w-full px-3 py-2 text-sm rounded-xl bg-slate-50 border-none font-bold text-center" />
                        </div>
                        <div className="col-span-1 flex justify-center pb-2">
                          <button type="button" onClick={() => removeItem(item.id)} className="text-slate-300 hover:text-rose-500 transition-colors"><Trash2 size={16} /></button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-4 pt-4">
                <button type="submit" className="flex-[2] bg-primary text-white font-black py-5 rounded-3xl hover:bg-primary-600 shadow-2xl transition-all hover:-translate-y-1">שלח בקשה</button>
                <button type="button" onClick={() => { setIsModalOpen(false); resetForm(); }} className="flex-1 bg-slate-100 text-slate-500 font-bold py-5 rounded-3xl">ביטול</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Requests;
