
export type UserRole = 'employee' | 'admin';

export interface Profile {
  id: string;
  username: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  department_id: string | null;
  approver_id: string | null;
  calendar_emails: string[];
  role: UserRole;
  password_hash?: string;
}

export interface Department {
  id: string;
  name: string;
}

export interface WFHTask {
  id: string;
  name: string;
  hours: number;
  referent: string;
}

export interface RequestItem {
  id: string;
  name: string;
  quantity: number;
}

export type RequestType = 'WFH' | 'Vacation' | 'Equipment' | 'Supplies';
export type RequestStatus = 'pending' | 'approved' | 'rejected' | 'ordered' | 'supplied' | 'cancelled';

export interface Request {
  id: string;
  user_id: string;
  user_name: string;
  request_type: RequestType;
  status: RequestStatus;
  start_date: string;
  end_date: string;
  reason: string;
  tasks?: WFHTask[];
  items?: RequestItem[];
  total_hours?: number;
  details?: string;
  approved_by?: string;
  approved_at?: string;
  created_at: string;
}

export interface AppSettings {
  webhook_url: string;
}

export interface Category {
  id: string;
  name: string;
}

export interface Article {
  id: string;
  title: string;
  summary: string;
  content: string;
  category_id: string;
  view_count: number;
  published_at: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  author_name: string;
  is_pinned: boolean;
  created_at: string;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
}

export interface Holiday {
  date: string;
  name: string;
}

// Fix missing automation types
export type AutomationTrigger = 'request_created' | 'request_approved' | 'request_rejected';
export type AutomationActionType = 'webhook' | 'email';

export interface AutomationHeader {
  key: string;
  value: string;
}

export interface Automation {
  id: string;
  name: string;
  trigger_type: AutomationTrigger;
  filter_request_type: RequestType | 'all';
  action_type: AutomationActionType;
  webhook_url?: string;
  method?: 'POST' | 'GET' | 'PUT' | 'DELETE';
  headers?: AutomationHeader[];
  email_subject?: string;
  payload_template: string;
  is_active: boolean;
  created_at: string;
  last_run?: string;
}
